import ChannelRoom from '@/components/ChannelRoom';

export default function ChannelPage() {
  return <ChannelRoom />;
} 